setTimeout(function() {
    var x = Math.floor(Math.random() * 1001);
    var y = Math.floor(Math.random() * 1001);
    particles.push({
        x,
        y
    }, 1000);

})